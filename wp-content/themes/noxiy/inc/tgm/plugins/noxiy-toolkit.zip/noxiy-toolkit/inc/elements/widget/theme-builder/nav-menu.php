<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Nav_Menu_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'nav_menu_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Nav Menu - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-builder'];
    }

    public function get_keywords()
    {
        return ['noxiy', 'Menu', 'Builder', 'Header', 'Custom'];
    }

    protected function register_controls()
    {


        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Menu Style', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Horizontal', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Vertical', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Custom Menu', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'nav_menu',
            [
                'label' => __('Select a Menu', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'options' => noxiy_nav_menu(),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'mobile_nav',
            [
                'label' => esc_html__('Mobile Menu', 'noxiy-toolkit'),
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );

        $this->add_control(
            'image_one',
            [
                'label' => esc_html__('Mobile Logo', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_url',
            [
                'label' => esc_html__('Logo URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('http://google.com', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );



        $this->add_control(
            'more_options',
            [
                'label' => esc_html__('Social Details', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'enable_social',
            [
                'label' => esc_html__('Social Area', 'noxiy-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'noxiy-toolkit'),
                'label_off' => esc_html__('No', 'noxiy-toolkit'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Social Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Follow Us', 'noxiy-toolkit'),
                'label_block' => true,
                'separator' => 'before',
                'condition' => [
                    'enable_social' => ['yes'],
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-facebook-f',
                    'library' => 'brands',
                ],
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'noxiy-toolkit'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'social_media',
            [
                'label' => esc_html__('Social Media', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'condition' => [
                    'enable_social' => ['yes'],
                ],
                'title_field' => '{{{ icon.value }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Custom Menu Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'menu_typography',
                'selector' => '{{WRAPPER}} .header__area-menubar-center-menu ul li a, {{WRAPPER}} .footer__area-widget-menu ul li a',
            ]
        );

        $this->add_responsive_control(
			'caption_align',
			[
				'label' => esc_html__( 'Menu Alignment', 'noxiy-toolkit' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'noxiy-toolkit' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'noxiy-toolkit' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'noxiy-toolkit' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .header__area-menubar-center-menu' => 'text-align: {{VALUE}};',
					'{{WRAPPER}} .menu__bar' => 'text-align: {{VALUE}};',
					'{{WRAPPER}} .footer__area-widget-menu ul' => 'text-align: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__('Border Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu li > a::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu' => 'border-color: {{VALUE}}',
                ],
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );

        $this->add_control(
            'menu_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu li > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li.menu-item-has-children > a::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .footer__area-widget-menu ul li a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );
        

        $this->add_control(
            'menu_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li:hover > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu li:hover > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li.menu-item-has-children:hover > a::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .footer__area-widget-menu ul li a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .footer__area-widget-menu ul li a::before' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'menu_height',
            [
                'label' => esc_html__('Menu Space', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul > li' => 'margin-right: {{SIZE}}{{UNIT}};margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .footer__area-widget-menu ul li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'submenu_height',
            [
                'label' => esc_html__('Sub Menu Space', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 150,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $image_one = $settings['image_one'];


        ?>

        <?php if ('design-1' === $settings['select_design']): ?>
            <div class="header__area-menubar-center-menu menu-responsive">
                <?php
                wp_nav_menu(
                    array(
                        'menu' => $settings['nav_menu'],
                        'menu_id' => 'mobilemenu',
                        'menu_class' => 'd-block',
                    )
                );
                ?>
            </div>


            <div class="header__area-menubar-right-responsive-menu menu__bar">
                <i class="flaticon-dots-menu"></i>
            </div>

            <div class="menu__bar-popup">
                <div class="menu__bar-popup-close"><i class="fal fa-times"></i></div>
                <div class="menu__bar-popup-left">

                    <div class="menu__bar-popup-left-logo">
                        <?php if ($image_one['url']): ?>
                            <a href="<?php echo esc_url($settings['image_url']); ?>">
                                <?php
                                if ($image_one['url']) {
                                    if (!empty($image_one['alt'])) {
                                        echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                                    } else {
                                        echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                    }
                                }
                                ?>
                            </a>
                        <?php endif; ?>
                        <div class="responsive-menu"></div>
                    </div>
                    <?php if ('yes' === $settings['enable_social'] && !empty($settings['social_media'])): ?>
                        <div class="menu__bar-popup-left-social">
                            <h6>
                                <?php echo esc_html($settings['content_one']); ?>
                            </h6>
                            <ul>
                                <?php foreach ($settings['social_media'] as $item): ?>
                                    <li><a href="<?php echo esc_url($item['link']['url']); ?>"><i
                                                class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']): ?>

            <div class="footer__area-widget-menu">
                <?php wp_nav_menu(
                    array(
                        'menu' => $settings['nav_menu'],
                        'menu_id' => 'mobilemenu',
                        'menu_class' => 'd-block',
                    )
                ); ?>
            </div>
        <?php endif; ?>


        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Nav_Menu_Noxiy);