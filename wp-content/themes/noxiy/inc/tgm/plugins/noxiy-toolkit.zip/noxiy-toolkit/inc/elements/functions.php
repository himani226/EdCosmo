<?php

if (!defined('ABSPATH'))
    exit; // No access of directly access
// Update Post Support
$cpt_support = get_option('elementor_cpt_support');

//check if option DOESN'T exist in db
if (!$cpt_support) {
    $cpt_support = ['page', 'post', 'service', 'portfolio', 'noxiy_builder'];
    update_option('elementor_cpt_support', $cpt_support);
}

// Disable default colors & default fonts
$disable_default_colors = 'yes';
$disable_default_fonts = 'yes';
update_option('elementor_disable_color_schemes', $disable_default_colors);
update_option('elementor_disable_typography_schemes', $disable_default_fonts);

// Register categories
function noxiy_toolkit_widget_categories($elements_manager)
{

    $elements_manager->add_category(
        'noxiy-toolkit',
        [
            'title' => esc_html__('Noxiy Toolkit', 'noxiy-toolkit'),
            'icon' => 'fa fa-plug',
        ]
    );

    $elements_manager->add_category(
        'noxiy-builder',
        [
            'title' => esc_html__('Theme Builder', 'noxiy-toolkit'),
            'icon' => 'fa fa-plug',
        ]
    );
}
add_action('elementor/elements/categories_registered', 'noxiy_toolkit_widget_categories');


// Custom Icon for Elementor

function noxify_custom_icons($noxify_custom_icons = array())
{

    $noxify_flaticon = array(
        'phone-call',
        'arrows',
        'family',
        'healthcare',
        'car-insurance',
        'home-insurance',
        'logistics-delivery',
        'conflagration',
        'farmhouse',
        'travel',
        'check-mark',
        'insurance',
        'health',
        'umbrella',
        'flood',
        'safe-flight',
        'earthquake',
        'protection',
        'protection-1',
        'download-to-storage-drive',
        'quote',
        'piggy-bank',
        'refund',
        'winner',
        'mission',
        'value',
        'vision',
        'meeting',
        'house',
        'select',
        'pdf',
        'pdf-file',
        'menu',
        'dots-menu',
        'quote-1',
        'travel-insurance',
        'customer-service',
        'businessman',
        '24-hours',
        'seller',
        'question-mark',
        'right-up',
        'customer-support',
        'umbrella-1',
        'saving',
        'trust',
        'question-mark-1',
        'success',
        'costumer',
        'project-management',
        'team',
        'medical-report',
        'social',
        'dental-insurance',
        'mental-health',
        'medical-records',
        'healthcare-1',
        'cost-saving',
        'review',
        'globe'
    );

    $noxify_custom_icons['noxify-icon_lists'] = array(
        'name' => 'noxify-icon_lists',
        'label' => esc_html__('Noxify - Premium', 'skb_cife'),
        'labelIcon' => 'far fa-sun',
        'prefix' => 'flaticon-',
        'displayPrefix' => 'flaticon',
        'url' => NOXIFY_ASSETS . 'fonts/flaticon.css',
        'icons' => $noxify_flaticon,
        'ver' => time(),
    );

    return $noxify_custom_icons;
}

add_filter('elementor/icons_manager/additional_tabs', 'noxify_custom_icons');





// Number of Comments
function noxiy_comments_count()
{
    $comments_number = get_comments_number();
    if ($comments_number == 0) {
        echo esc_html__('Comment', 'noxiy-toolkit') . ' (0)';
    } elseif ($comments_number == 1) {
        echo esc_html__('Comment', 'noxiy-toolkit') . ' (1)';
    } else {
        echo esc_html__('Comments', 'noxiy-toolkit') . ' (' . $comments_number . ')';
    }
}


// Post Category
function noxiy_post_categories()
{
    $options = array();
    $post_categories_terms = get_terms(
        array(
            'taxonomy' => 'category',
            'hide_empty' => true,
        )
    );

    if (!empty($post_categories_terms) && !is_wp_error($post_categories_terms)) {
        foreach ($post_categories_terms as $term) {
            $options[$term->slug] = $term->name;
        }
    }

    return $options;
}

// Portfolio Category
function noxiy_portfolio_categories()
{
    $options = array();
    $portfolio_categories_terms = get_terms(
        array(
            'taxonomy' => 'portfolio_category',
            'hide_empty' => true,
        )
    );

    if (!empty($portfolio_categories_terms) && !is_wp_error($portfolio_categories_terms)) {
        foreach ($portfolio_categories_terms as $term) {
            $options[$term->slug] = $term->name;
        }
    }

    return $options;
}

// Display Menu
function noxiy_nav_menu()
{
    $menu_list = get_terms(
        array(
            'taxonomy' => 'nav_menu',
            'hide_empty' => true,
        )
    );
    $options = [];
    if (!empty($menu_list) && !is_wp_error($menu_list)) {
        foreach ($menu_list as $menu) {
            $options[$menu->term_id] = $menu->name;
        }
        return $options;
    }
}

// Display Template Builders 
function noxiy_template_builder()
{

    $template_list = array(
        'post_type' => 'noxiy_builder',
        'posts_per_page' => -1,
    );

    $templates = get_posts($template_list);

    $options = [];

    if (!empty($templates) && !is_wp_error($templates)) {
        foreach ($templates as $template) {
            $options[$template->ID] = $template->post_title;
        }
        return $options;
    }
}


// contact form remove auto p tag and space 
add_filter('wpcf7_autop_or_not', '__return_false');

/*
disable Custom Post Types from Search Results
*/

function noxiy_cpt_from_search($query)
{
    if (!is_admin() && $query->is_main_query() && $query->is_search()) {
        $exclude_post_type = 'noxiy_builder';
        $query->set('post_type', array_diff(get_post_types(), array($exclude_post_type)));
    }
}
add_action('pre_get_posts', 'noxiy_cpt_from_search');