<?php

namespace Elementor;

use Elementor\Utils;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;

if (!defined('ABSPATH'))
    exit;

class Banner_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'banner_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Banner - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Conbix', 'Toolkit', 'Banner', 'Slider', 'Home'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_general',
            [
                'label' => esc_html__('Style & Options', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select Banner Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Banner Style 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Banner Style 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Banner Style 03', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );

        $this->add_control(
            'banner_arrow',
            [
                'label' => esc_html__('Show Arrow/Dots', 'noxiy-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'noxiy-toolkit'),
                'label_off' => esc_html__('No', 'noxiy-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'enable_shape',
            [
                'label' => esc_html__('Shape Enable', 'noxiy-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'noxiy-toolkit'),
                'label_off' => esc_html__('No', 'noxiy-toolkit'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_general2',
            [
                'label' => esc_html__('Shape Image', 'noxiy-toolkit'),
            ]
        );


        $this->add_control(
            'theme_shape_img1',
            [
                'label' => esc_html__('Shape One', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1', 'design-2', 'design-3'],
                ]
            ]
        );

        $this->add_control(
            'theme_shape_img2',
            [
                'label' => esc_html__('Shape Two', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1', 'design-2'],
                ]
            ]
        );

        $this->add_control(
            'theme_shape_img3',
            [
                'label' => esc_html__('Shape Three', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1', 'design-2'],
                ]
            ]
        );

        $this->add_control(
            'theme_shape_img4',
            [
                'label' => esc_html__('Shape Four', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1', 'design-2'],
                ]
            ]
        );

        $this->end_controls_section();




        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Slider Content', 'noxiy-toolkit'),
            ]
        );


        $banner_slider = new Repeater();


        $banner_slider->add_control(
            'slider_image',
            [
                'label' => esc_html__('Choose Image', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_subtitle',
            [
                'label' => esc_html__('Sub Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_title',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_description',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_btn_text',
            [
                'label' => esc_html__('Button Text', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_btn_url',
            [
                'label' => esc_html__('Button URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $banner_slider->add_control(
            'slider_video_url',
            [
                'label' => esc_html__('Video URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );



        $this->add_control(
            'banner_slides',
            [
                'label' => esc_html__('Banner Slides', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $banner_slider->get_controls(),
                'default' => [
                    [
                        'slider_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'slider_subtitle' => esc_html__('Welcome to Conbix', 'noxiy-toolkit'),
                        'slider_title' => esc_html__('Business consulting advice', 'noxiy-toolkit'),
                        'slider_description' => esc_html__('We help small startups grow from idea to millions of users', 'noxiy-toolkit'),
                        'slider_btn_text' => esc_html__('Read More', 'noxiy-toolkit'),
                        'slider_btn_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                        'slider_video_url' => esc_attr__('https://www.youtube.com/watch?v=SZEflIVnhH8', 'noxiy-toolkit'),
                    ],

                    [
                        'slider_image' => [
                            'url' => Utils::get_placeholder_image_src(),
                        ],
                        'slider_subtitle' => esc_html__('Welcome to Conbix', 'noxiy-toolkit'),
                        'slider_title' => esc_html__('Business consulting advice', 'noxiy-toolkit'),
                        'slider_description' => esc_html__('We help small startups grow from idea to millions of users', 'noxiy-toolkit'),
                        'slider_btn_text' => esc_html__('Read More', 'noxiy-toolkit'),
                        'slider_btn_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                        'slider_video_url' => esc_attr__('https://www.youtube.com/watch?v=SZEflIVnhH8', 'noxiy-toolkit'),
                    ],
                ],

                'title_field' => '{{{ slider_subtitle }}}',
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $theme_shape_img1 = $settings['theme_shape_img1'];
        $theme_shape_img2 = $settings['theme_shape_img2'];
        $theme_shape_img3 = $settings['theme_shape_img3'];
        $theme_shape_img4 = $settings['theme_shape_img4'];


        ?>
        <?php if ('design-1' === $settings['select_design'] && !empty($settings['banner_slides'])): ?>


            <!-- Banner Area Start -->
            <div class="banner__two">
                <?php if ('yes' === $settings['enable_shape']): ?>
                    <div class="banner__two-shape">
                        <?php if (!empty($theme_shape_img1['url'])): ?>
                            <img class="banner__two-shape-one" src="<?php echo esc_url($theme_shape_img1['url']); ?>" alt="banner-shape">
                        <?php endif; ?>

                        <?php if (!empty($theme_shape_img2['url'])): ?>
                            <img class="banner__two-shape-two left-right-animate" src="<?php echo esc_url($theme_shape_img2['url']); ?>"
                                alt="banner-shape">
                        <?php endif; ?>

                        <?php if (!empty($theme_shape_img3['url'])): ?>
                            <img class="banner__two-shape-three" src="<?php echo esc_url($theme_shape_img3['url']); ?>" alt="banner-shape">
                        <?php endif; ?>

                        <?php if (!empty($theme_shape_img4['url'])): ?>
                            <img class="banner__two-shape-four" src="<?php echo esc_url($theme_shape_img4['url']); ?>" alt="banner-shape">
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <div class="swiper banner-slider">
                    <div class="swiper-wrapper">
                        <?php foreach ($settings['banner_slides'] as $slide): ?>
                            <div class="swiper-slide">
                                <div class="banner__two-bg">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-xl-7 col-lg-8">
                                                <div class="banner__two-content">
                                                    <span data-animation="fadeInLeft" data-delay=".3s">
                                                        <?php echo esc_html($slide['slider_subtitle']); ?>
                                                    </span>
                                                    <h1 data-animation="fadeInLeft" data-delay=".6s">
                                                        <?php echo esc_html($slide['slider_title']); ?>
                                                    </h1>
                                                    <p data-animation="fadeInLeft" data-delay=".9s">
                                                        <?php echo esc_html($slide['slider_description']); ?>
                                                    </p>
                                                    <div class="banner__two-content-button" data-animation="fadeInLeft" data-delay="1s">
                                                        <a class="btn-two" href="<?php echo esc_url($slide['slider_btn_url']); ?>"><?php echo esc_html($slide['slider_btn_text']); ?></a>
                                                        <div class="banner__two-content-button-video video-pulse">
                                                            <a class="video-popup"
                                                                href="<?php echo esc_url($slide['slider_video_url']); ?>"><i
                                                                    class="fas fa-play"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-xl-5 col-lg-4">
                                                <div class="banner__two-right" data-animation="fadeInRight" data-delay="1.4s">
                                                    <img src="<?php echo esc_url($slide['slider_image']['url']) ?>" alt="banner-image">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php if ('yes' === $settings['banner_arrow']): ?>
                    <div class="banner__two-arrow">
                        <div class="banner__two-arrow-prev noxiy-button-prev"><i class="fal fa-long-arrow-left"></i></div>
                        <div class="banner__two-arrow-next noxiy-button-next"><i class="fal fa-long-arrow-right"></i></div>
                    </div>
                <?php endif; ?>
            </div>
            <!-- Banner Area End -->

        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design'] && !empty($settings['banner_slides'])): ?>
            <!-- Banner Area Start -->
            <div class="banner__one swiper banner-slider">
                <div class="swiper-wrapper">
                    <?php foreach ($settings['banner_slides'] as $slide): ?>
                        <div class="swiper-slide">
                            <div class="banner__one-image" data-background="<?php echo esc_url($slide['slider_image']['url']) ?>"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="banner__one-content">
                                            <span data-animation="fadeInUp" data-delay=".3s">
                                                <?php echo esc_html($slide['slider_subtitle']); ?>
                                            </span>
                                            <h1 data-animation="fadeInUp" data-delay=".7s">
                                                <?php echo esc_html($slide['slider_title']); ?>
                                            </h1>
                                            <div class="banner__one-content-button" data-animation="fadeInUp" data-delay="1s">
                                                <a class="btn-one" href="<?php echo esc_url($slide['slider_btn_url']); ?>"><?php echo esc_html($slide['slider_btn_text']); ?></a>
                                                <div class="banner__one-content-button-video video-pulse">
                                                    <a class="video-popup" href="<?php echo esc_url($slide['slider_video_url']); ?>"><i
                                                            class="fas fa-play"></i></a>
                                                </div>
                                            </div>
                                            <?php if (!empty($theme_shape_img1['url'])): ?>
                                                <img class="banner__one-shape-four" src="<?php echo esc_url($theme_shape_img1['url']); ?>"
                                                    alt="banner-shape">
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!empty($theme_shape_img2['url'])): ?>
                                            <img class="banner__one-shape-two" src="<?php echo esc_url($theme_shape_img2['url']); ?>"
                                                data-animation="fadeInUpBig" data-delay="2s" alt="banner-shape">
                                        <?php endif; ?>
                                        <?php if (!empty($theme_shape_img3['url'])): ?>
                                            <img class="banner__one-shape-three" src="<?php echo esc_url($theme_shape_img3['url']); ?>"
                                                data-animation="fadeInRightBig" data-delay="1.5s" alt="banner-shape">
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; ?>
                </div>
                <?php if ('yes' === $settings['banner_arrow']): ?>
                    <div class="banner__one-arrow">
                        <div class="banner__one-arrow-prev noxiy-button-prev"><i class="fal fa-long-arrow-left"></i></div>
                        <div class="banner__one-arrow-next noxiy-button-next"><i class="fal fa-long-arrow-right"></i></div>
                    </div>
                <?php endif; ?>
                <?php if (!empty($theme_shape_img4['url'])): ?>
                    <img class="banner__one-shape-one" src="<?php echo esc_url($theme_shape_img4['url']); ?>" alt="banner-shape">
                <?php endif; ?>
            </div>
            <!-- Banner Area End -->
        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']): ?>
            <!-- Banner Area Start -->
            <div class="banner__three swiper banner-slider">
                <div class="swiper-wrapper">
                    <?php foreach ($settings['banner_slides'] as $slide): ?>
                        <div class="banner__three-image swiper-slide"
                            data-background="<?php echo esc_url($slide['slider_image']['url']) ?>">
                            <?php if (!empty($theme_shape_img1['url'])): ?>
                                <img class="banner__three-shape" src="<?php echo esc_url($theme_shape_img1['url']); ?>" alt="banner-shape">
                            <?php endif; ?>
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="banner__three-content">
                                            <span data-animation="fadeInUp" data-delay=".3s">
                                                <?php echo esc_html($slide['slider_subtitle']); ?>
                                            </span>
                                            <h1 data-animation="fadeInUp" data-delay=".6s">
                                                <?php echo esc_html($slide['slider_title']); ?>
                                            </h1>
                                            <p data-animation="fadeInUp" data-delay=".9s">
                                                <?php echo esc_html($slide['slider_description']); ?>
                                            </p>
                                            <div class="banner__three-content-button" data-animation="fadeInUp" data-delay="1.2s">
                                                <a class="btn-one" href="<?php echo esc_url($slide['slider_btn_url']); ?>"><?php echo esc_html($slide['slider_btn_text']); ?></a>
                                                <div class="banner__three-content-button-video video-pulse">
                                                    <a class="video-popup" href="<?php echo esc_url($slide['slider_video_url']); ?>"><i
                                                            class="fas fa-play"></i></a>
                                                </div>
                                            </div>
                                            <?php if ('yes' === $settings['banner_arrow']): ?>
                                                <div class="banner-pagination"></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- Banner Area Start -->
        <?php endif; ?>
    <?php
    }
}

Plugin::instance()->widgets_manager->register(new Banner_Noxiy);