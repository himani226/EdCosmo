<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Contact_Info_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'contact-info-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Contact Info - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Contact', 'info'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Design Style', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Style 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Style 02', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon_1',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'far fa-sun',
                    'library' => 'brands',
                ],
                'condition' => [
                    'select_design' => ['design-2'],
                ]
            ]
        );
        


        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Office Location', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'item_url',
            [
                'label' => esc_html__('Item URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2'],
                ]
            ]
        );

        $this->add_control(
            'prefix',
            [
                'label' => esc_html__('Sign', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__(':', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );


        $this->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('8502 Preston Rd. Inglewood', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1'],
                ]
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>
        <?php if ('design-1' === $settings['select_design']): ?>
            <div class="contact__two-info-item">
                <h6>
                    <?php echo esc_html($settings['title']); ?><span>
                        <?php echo esc_html($settings['prefix']); ?>
                    </span>
                </h6>
                <span>
                    <?php echo esc_html($settings['content']); ?>
                </span>
            </div>
        <?php endif; ?>
        <?php if ('design-2' === $settings['select_design']): ?>
            <div class="cta__two-item">
                <div class="cta__two-item-info">
                    <div class="cta__two-item-info-icon">
                        <i class="<?php echo esc_attr($settings['icon_1']['value']); ?>"></i>
                        <i class="<?php echo esc_attr($settings['icon_1']['value']); ?>"></i>
                    </div>
                    <h4><a href="<?php echo esc_url($settings['item_url']); ?>"><?php echo esc_html($settings['title']); ?></a></h4>
                </div>
                <a href="<?php echo esc_url($settings['item_url']); ?>"><i class="fal fa-long-arrow-right"></i></a>
            </div>
        <?php endif; ?>
    <?php
    }
}

Plugin::instance()->widgets_manager->register(new Contact_Info_Noxiy);