<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Counter_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'counter-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Counter - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Counter', 'left', 'right'];
    }

    protected function register_controls()
    {


        $this->start_controls_section(
            'counter_section_content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
            ]
        );        

        $this->add_control(
            'content_number',
            [
                'label' => esc_html__('Content Number', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('31', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'content_prefix',
            [
                'label' => esc_html__('Counter Prefix', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('+', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('SubTitle', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Happy Customer', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => esc_html__('Alignment', 'noxiy-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item' => 'justify-content: {{VALUE}};',
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'counter_icon_style_section',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item-icon i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item-icon i' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_space',
            [
                'label' => esc_html__('Gap', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 20,
				],
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'icon_width',
            [
                'label' => esc_html__('Max Width', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 100,
				],
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item-icon i' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );        

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 45,
				],
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
			'icon_border_radius',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Border Radius', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .counter__two-item-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'content_style_section',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_control(
			'counter_heading',
			[
				'label' => esc_html__( 'Heading', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

        $this->add_control(
            'heading_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item-content h2' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'selector' => '{{WRAPPER}} .counter__two-item-content h2',
			]
		);

		$this->add_control(
			'counter_subtitle',
			[
				'label' => esc_html__( 'Subtitle', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

        $this->add_control(
            'subtitle_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .counter__two-item-content h6' => 'color: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'selector' => '{{WRAPPER}} .counter__two-item-content h6',
			]
		);

        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();
        ?>
            <div class="counter__two-item">
                <div class="counter__two-item-icon">
					<i class="<?php echo esc_attr($settings['icon']['value']); ?>"></i>
                </div>
                <div class="counter__two-item-content">
                    <h2>
                        <span class="counter">
                            <?php echo esc_html($settings['content_number']); ?>
                        </span>
                        <?php echo esc_html($settings['content_prefix']); ?>
                    </h2>
                    <h6>
                        <?php echo esc_html($settings['content_one']); ?>
                    </h6>
                </div>
            </div>

    <?php
}
}

Plugin::instance()->widgets_manager->register(new Counter_Noxiy);