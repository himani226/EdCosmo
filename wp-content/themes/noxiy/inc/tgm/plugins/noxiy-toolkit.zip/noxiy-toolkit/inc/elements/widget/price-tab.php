<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Price_Tab_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'price_tab_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Price Tab - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'price', 'tab', 'table'];
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'head_monthly',
            [
                'label' => esc_html__('Monthly Template', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Monthly Button', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Monthly', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'select_monthly',
            [
                'label' => __('Select Monthly', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'options' => noxiy_template_builder(),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'head_yearly',
            [
                'label' => esc_html__('Yearly Template', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'content_two',
            [
                'label' => esc_html__('Yearly Button', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Yearly', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->add_control(
            'select_yearly',
            [
                'label' => __('Select Yearly', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'options' => noxiy_template_builder(),
                'label_block' => true,
            ]
        );



        $this->end_controls_section();

    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>

        <div class="pricing__two-button">
            <ul class="nav nav-pills">
                <li class="nav-item"><button class="active" data-bs-toggle="pill" data-bs-target="#monthly">
                        <?php echo esc_html($settings['content_one']); ?>
                    </button>
                </li>
                <li class="nav-item" role="presentation"><button data-bs-toggle="pill" data-bs-target="#yearly">
                        <?php echo esc_html($settings['content_two']); ?>
                    </button>
                </li>
            </ul>
        </div>


        <div class="tab-content">
            <div class="tab-pane fade show active" id="monthly">
                <?php
                if (!empty($settings['select_monthly'])) {
                    // The plugin's function to get the content of the selected custom template
                    echo Plugin::$instance->frontend->get_builder_content($settings['select_monthly'], true);
                } else {
                    // If no custom template is selected
                    echo 'Please select a template.';
                }
                ?>
            </div>
            <div class="tab-pane fade" id="yearly">
                <?php
                if (!empty($settings['select_yearly'])) {
                    // The plugin's function to get the content of the selected custom template
                    echo Plugin::$instance->frontend->get_builder_content($settings['select_yearly'], true);
                } else {
                    // If no custom template is selected
                    echo 'Please select a template.';
                }
                ?>
            </div>
        </div>


        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Price_Tab_Noxiy);