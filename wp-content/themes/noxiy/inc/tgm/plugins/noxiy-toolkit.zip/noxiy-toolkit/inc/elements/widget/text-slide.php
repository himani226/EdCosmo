<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Text_Slide_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'text-slide-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Text Slide - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'slide', 'text', 'content', 'slider'];
    }

    protected function register_controls()
    {



        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Slide Content', 'noxiy-toolkit'),
            ]
        );


        $text_slide = new Repeater();

        $text_slide->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
            ]
        );


        $text_slide->add_control(
            'text_slide_content',
            [
                'label' => esc_html__('Content', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );

        $text_slide->add_control(
            'text_slide_url',
            [
                'label' => esc_html__('Content URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );



        $this->add_control(
            'text_slides',
            [
                'label' => esc_html__('Text Slides', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $text_slide->get_controls(),
                'default' => [
                    [

                        'text_slide_content' => esc_html__('Disability Insurance', 'noxiy-toolkit'),
                        'text_slide_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),
                    ],

                    [

                        'text_slide_content' => esc_html__('Family Insurance', 'noxiy-toolkit'),
                        'text_slide_url' => esc_attr__('http://google.com', 'noxiy-toolkit'),

                    ],
                ],

                'title_field' => '{{{ text_slide_content }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slider_background',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'slider_background_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text__slider' => 'background: {{VALUE}}',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_responsive_control(
			'bg_padding',
			[
				'type' => Controls_Manager::DIMENSIONS,
				'label' => esc_html__( 'Padding', 'noxiy-toolkit' ),
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .text__slider' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
            'heading_style_section',
            [
                'label' => esc_html__('Heading Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'heading_typography',
				'selector' => '{{WRAPPER}} .text__slider ul li h2',
			]
		);

        $this->add_control(
            'heading_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text__slider ul li h2 a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'heading_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text__slider ul li h2 a:hover' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'icon_style_section',
            [
                'label' => esc_html__('Icon Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .text__slider ul li span' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_opacity',
            [
                'label' => esc_html__('Opacity', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 0.5,
				],
                'selectors' => [
                    '{{WRAPPER}} .text__slider ul li span' => 'opacity: {{SIZE}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'icon_space',
            [
                'label' => esc_html__('Space', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 40,
				],
                'selectors' => [
                    '{{WRAPPER}} .text__slider ul li span' => 'margin-left: {{SIZE}}{{UNIT}};margin-right: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'default' => [
					'unit' => 'px',
					'size' => 28,
				],
                'selectors' => [
                    '{{WRAPPER}} .text__slider ul li span' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>



        <!-- Text Slider Area Start -->
        <div class="text__slider two">
            <div class="text-slide">
                <div class="sliders scroll">
                    <ul>
                        <?php foreach ($settings['text_slides'] as $item): ?>
                            <li>
                                <h2><a href="<?php echo esc_url($item['text_slide_url']); ?>"><?php echo esc_html($item['text_slide_content']); ?></a><span
                                        class="<?php echo esc_attr($item['icon']['value']); ?>"></span></h2>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="sliders scroll">
                    <ul>
                        <?php foreach ($settings['text_slides'] as $item): ?>
                            <li>
                                <h2><a href="<?php echo esc_url($item['text_slide_url']); ?>"><?php echo esc_html($item['text_slide_content']); ?></a><span
                                        class="<?php echo esc_attr($item['icon']['value']); ?>"></span></h2>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
        <!-- Text Slider Area Start -->

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Text_Slide_Noxiy);