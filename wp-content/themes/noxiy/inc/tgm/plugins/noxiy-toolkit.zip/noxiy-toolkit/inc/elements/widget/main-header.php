<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Main_Header_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'main_header_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Main Header - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['noxiy', 'Menu', 'Builder', 'Header', 'Custom'];
    }

    protected function register_controls()
    {


        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_design',
            [
                'label' => esc_html__('Select a Style', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'design-1' => esc_html__('Design 01', 'noxiy-toolkit'),
                    'design-2' => esc_html__('Design 02', 'noxiy-toolkit'),
                    'design-3' => esc_html__('Design 03', 'noxiy-toolkit'),
                ],
                'default' => 'design-1',
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'logo_headeing',
            [
                'label' => esc_html__('Main Logo', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'logo',
            [
                'label' => esc_html__('Logo', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'logo_url',
            [
                'label' => esc_html__('Logo URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('http://google.com', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'serach_headeing',
            [
                'label' => esc_html__('Search', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'placeholder',
            [
                'label' => esc_html__('Search Placeholder', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Search...', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'offcanvas_headeing',
            [
                'label' => esc_html__('Offcanvas', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
                'condition' => [
                    'select_design' => ['design-1','design-3'],
                ]
            ]
        );

        $this->add_control(
            'select_emplate',
            [
                'label' => __('Offcanvas Template', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'options' => noxiy_template_builder(),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-1','design-3'],
                ]
            ]
        );

        $this->add_control(
            'btn_headeing',
            [
                'label' => esc_html__('Button', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'btn_one',
            [
                'label' => esc_html__('Button', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Read More', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'btn_link',
            [
                'label' => esc_html__('Link', 'noxiy-toolkit'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://example.com', 'noxiy-toolkit'),
                'options' => ['url', 'is_external', 'nofollow'],
                'default' => [
                    'url' => '#',
                ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'cta_headeing',
            [
                'label' => esc_html__('Contact Info', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'cta_icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-phone',
                    'library' => 'brands',
                ],
                'condition' => [
                    'select_design' => ['design-2', 'design-3'],
                ],
            ]
        );

        $this->add_control(
            'cta_subtitle',
            [
                'label' => esc_html__('Contact Subtitle', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Free contact 24/7', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2', 'design-3'],
                ],
            ]
        );

        $this->add_control(
            'cta_title',
            [
                'label' => esc_html__('Contact Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('+1405 555-0128', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2', 'design-3'],
                ],
            ]
        );

        $this->add_control(
            'cta_item_url',
            [
                'label' => esc_html__('Contact URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_attr__('tel:+1405 555-0128', 'noxiy-toolkit'),
                'label_block' => true,
                'condition' => [
                    'select_design' => ['design-2', 'design-3'],
                ],
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'menu_content',
            [
                'label' => esc_html__('Custom Menu', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'nav_menu',
            [
                'label' => __('Select a Menu', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'options' => noxiy_nav_menu(),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'mobile_nav',
            [
                'label' => esc_html__('Mobile Menu', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'image_one',
            [
                'label' => esc_html__('Mobile Logo', 'noxiy-toolkit'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'image_url',
            [
                'label' => esc_html__('Logo URL', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('http://google.com', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );



        $this->add_control(
            'more_options',
            [
                'label' => esc_html__('Social Details', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'enable_social',
            [
                'label' => esc_html__('Social Area', 'noxiy-toolkit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'noxiy-toolkit'),
                'label_off' => esc_html__('No', 'noxiy-toolkit'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'content_one',
            [
                'label' => esc_html__('Social Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Follow Us', 'noxiy-toolkit'),
                'label_block' => true,
                'separator' => 'before',
                'condition' => [
                    'enable_social' => ['yes'],
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fab fa-facebook-f',
                    'library' => 'brands',
                ],
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'noxiy-toolkit'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'social_media',
            [
                'label' => esc_html__('Social Media', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'condition' => [
                    'enable_social' => ['yes'],
                ],
                'title_field' => '{{{ icon.value }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Custom Menu Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'logo_width',
            [
                'label' => esc_html__('Logo Width', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 150,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-left-logo a img' => 'max-width: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'menu_typography',
                'selector' => '{{WRAPPER}} .header__area-menubar-center-menu ul li a, {{WRAPPER}} .footer__area-widget-menu ul li a',
            ]
        );

        $this->add_responsive_control(
            'caption_align',
            [
                'label' => esc_html__('Menu Alignment', 'noxiy-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .menu__bar' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .footer__area-widget-menu ul' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label' => esc_html__('Border Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu li > a::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu' => 'border-color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'menu_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu li > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li.menu-item-has-children > a::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .footer__area-widget-menu ul li a' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );


        $this->add_control(
            'menu_hover_color',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li:hover > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu li:hover > a' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li.menu-item-has-children:hover > a::before' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .footer__area-widget-menu ul li a:hover' => 'color: {{VALUE}}',
                    '{{WRAPPER}} .footer__area-widget-menu ul li a::before' => 'color: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'menu_height',
            [
                'label' => esc_html__('Menu Space', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul > li' => 'margin-right: {{SIZE}}{{UNIT}};margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .footer__area-widget-menu ul li' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'submenu_height',
            [
                'label' => esc_html__('Sub Menu Space', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 150,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-center-menu ul li .sub-menu' => 'top: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'offcanvas_style_section',
            [
                'label' => esc_html__('Offcanvas Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup-icon i::before' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'more_options',
            [
                'label' => esc_html__('Offcanvas', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'popup_bg',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup' => 'background: {{VALUE}}',
                ],
            ]
        );


        $this->add_control(
            'popup_icon_color',
            [
                'label' => esc_html__('Close Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup .sidebar-close-btn i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'popup_icon_bg',
            [
                'label' => esc_html__('Close Icon BG', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup .sidebar-close-btn i' => 'background: {{VALUE}}',
                ],
            ]
        );


        $this->end_controls_section();


        $this->start_controls_section(
            'btn_style_section',
            [
                'label' => esc_html__('Button Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'selector' => '{{WRAPPER}} .btn-one',
            ]
        );

        $this->start_controls_tabs(
            'style_tabs'
        );

        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => esc_html__('Normal', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-one' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'button_background_color',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-one' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'style_hover_tab',
            [
                'label' => esc_html__('Hover', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'btn_hover_text_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-one:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'btn_hover_background_color',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn-one::after' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .btn-one::before' => 'background: {{VALUE}}',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_responsive_control(
            'button_border_radius',
            [
                'type' => Controls_Manager::DIMENSIONS,
                'label' => esc_html__('Border Radius', 'noxiy-toolkit'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .btn-one' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'type' => Controls_Manager::DIMENSIONS,
                'label' => esc_html__('Padding', 'noxiy-toolkit'),
                'size_units' => ['px', '%', 'em', 'rem', 'custom'],
                'selectors' => [
                    '{{WRAPPER}} .btn-one' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();


        $this->start_controls_section(
            'search_style_section',
            [
                'label' => esc_html__('Search Style', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'search_icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-icon.open i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'search_icon_hover',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-icon.open i:hover' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'more_options1',
            [
                'label' => esc_html__('Search Form', 'noxiy-toolkit'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'input_icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-box button' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();

    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        $logo = $settings['logo'];
        $image_one = $settings['image_one'];

        if (!empty($settings['btn_link']['url'])) {
            $this->add_link_attributes('btn_link', $settings['btn_link']);
        }
        ?>

        <?php if ('design-1' === $settings['select_design']): ?>


            <!-- Header Area Start -->
            <div class="header__area header__sticky">
                <div class="custom__container">
                    <div class="header__area-menubar p-relative">
                        <div class="header__area-menubar-left">
                            <div class="header__area-menubar-left-logo">

                                <?php if ($logo['url']): ?>
                                    <a href="<?php echo esc_url($settings['logo_url']); ?>">
                                        <?php
                                        if ($logo['url']) {
                                            if (!empty($logo['alt'])) {
                                                echo '<img src="' . esc_url($logo['url']) . '" alt="' . esc_attr($logo['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($logo['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                            }
                                        }
                                        ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="header__area-menubar-center">
                            <div class="header__area-menubar-center-menu menu-responsive">

                                <?php
                                wp_nav_menu(
                                    array(
                                        'menu' => $settings['nav_menu'],
                                        'menu_id' => 'mobilemenu',
                                        'menu_class' => 'd-block',
                                    )
                                );
                                ?>

                            </div>
                        </div>
                        <div class="header__area-menubar-right">
                            <div class="header__area-menubar-right-search">
                                <div class="search">
                                    <span class="header__area-menubar-right-search-icon open"><i class="fal fa-search"></i></span>
                                </div>
                                <div class="header__area-menubar-right-search-box">
                                    <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
                                        <input type="search" placeholder="<?php echo esc_attr($settings['placeholder']); ?>"
                                            value="<?php the_search_query(); ?>" name="s">
                                        <button value="Search" type="submit"><i class="fal fa-search"></i>
                                        </button>
                                    </form>
                                    <span class="header__area-menubar-right-search-box-icon"><i class="fal fa-times"></i></span>
                                </div>
                            </div>
                            <div class="header__area-menubar-right-sidebar">
                                <div class="header__area-menubar-right-sidebar-popup-icon"><i class="flaticon-dots-menu"></i></div>
                            </div>
                            <div class="header__area-menubar-right-btn">

                                <a <?php echo $this->get_render_attribute_string('btn_link'); ?> class="btn-one">
                                    <?php echo esc_html($settings['btn_one']); ?>
                                </a>
                            </div>
                            <div class="header__area-menubar-right-responsive-menu menu__bar">
                                <i class="flaticon-dots-menu"></i>
                            </div>
                            <!-- sidebar Menu Start -->
                            <div class="header__area-menubar-right-sidebar-popup">
                                <div class="sidebar-close-btn"><i class="fal fa-times"></i></div>
                                <?php
                                if (!empty($settings['select_emplate'])) {
                                    // The plugin's function to get the content of the selected custom template
                                    echo Plugin::$instance->frontend->get_builder_content($settings['select_emplate'], true);
                                } else {
                                    // If no custom template is selected
                                    echo 'Please select a template.';
                                }
                                ?>

                            </div>
                            <div class="sidebar-overlay"></div>
                            <!-- sidebar Menu Start -->
                        </div>
                    </div>
                    <div class="menu__bar-popup">
                        <div class="menu__bar-popup-close"><i class="fal fa-times"></i></div>
                        <div class="menu__bar-popup-left">
                            <div class="menu__bar-popup-left-logo">
                                <?php if ($image_one['url']): ?>
                                    <a href="<?php echo esc_url($settings['image_url']); ?>">
                                        <?php
                                        if ($image_one['url']) {
                                            if (!empty($image_one['alt'])) {
                                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                            }
                                        }
                                        ?>
                                    </a>
                                <?php endif; ?>
                                <div class="responsive-menu"></div>
                            </div>
                            <?php if ('yes' === $settings['enable_social'] && !empty($settings['social_media'])): ?>
                                <div class="menu__bar-popup-left-social">
                                    <h6>
                                        <?php echo esc_html($settings['content_one']); ?>
                                    </h6>
                                    <ul>
                                        <?php foreach ($settings['social_media'] as $item): ?>
                                            <li><a href="<?php echo esc_url($item['link']['url']); ?>"><i
                                                        class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header Area End -->

        <?php endif; ?>

        <?php if ('design-2' === $settings['select_design']): ?>
            <!-- Header Area Start -->
            <div class="header__area one header__sticky">
                <div class="container custom__container">
                    <div class="header__area-menubar p-relative">
                        <div class="header__area-menubar-left">
                            <div class="header__area-menubar-left-logo">
                                <?php if ($logo['url']): ?>
                                    <a href="<?php echo esc_url($settings['logo_url']); ?>">
                                        <?php
                                        if ($logo['url']) {
                                            if (!empty($logo['alt'])) {
                                                echo '<img src="' . esc_url($logo['url']) . '" alt="' . esc_attr($logo['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($logo['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                            }
                                        }
                                        ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="header__area-menubar-center">
                            <div class="header__area-menubar-center-menu four menu-responsive">

                                <?php
                                wp_nav_menu(
                                    array(
                                        'menu' => $settings['nav_menu'],
                                        'menu_id' => 'mobilemenu',
                                        'menu_class' => 'd-block',
                                    )
                                );
                                ?>

                            </div>
                        </div>
                        <div class="header__area-menubar-right">
                            <div class="header__area-menubar-right-search four">
                                <div class="search">
                                    <span class="header__area-menubar-right-search-icon open"><i class="fal fa-search"></i></span>
                                </div>
                                <div class="header__area-menubar-right-search-box">
                                    <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
                                        <input type="search" placeholder="<?php echo esc_attr($settings['placeholder']); ?>"
                                            value="<?php the_search_query(); ?>" name="s">
                                        <button value="Search" type="submit"><i class="fal fa-search"></i>
                                        </button>
                                    </form>
                                    <span class="header__area-menubar-right-search-box-icon"><i class="fal fa-times"></i></span>
                                </div>
                            </div>
                            <div class="header__area-menubar-right-responsive-menu menu__bar two">
                                <i class="flaticon-dots-menu"></i>
                            </div>
                            <div class="header__area-menubar-right-contact">
                                <div class="header__area-menubar-right-contact-icon">
                                    <i class="<?php echo esc_attr($settings['cta_icon']['value']); ?>"></i>
                                </div>
                                <div class="header__area-menubar-right-contact-info">
                                    <span>
                                        <?php echo esc_html($settings['cta_subtitle']); ?>
                                    </span>
                                    <h6><a href="<?php echo esc_url($settings['cta_item_url']); ?>"><?php echo esc_html($settings['cta_title']); ?></a></h6>
                                </div>
                            </div>
                            <div class="header__area-menubar-right-btn four">
                                <a <?php echo $this->get_render_attribute_string('btn_link'); ?> class="btn-one">
                                    <?php echo esc_html($settings['btn_one']); ?>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="menu__bar-popup four">
                        <div class="menu__bar-popup-close"><i class="fal fa-times"></i></div>
                        <div class="menu__bar-popup-left">
                            <div class="menu__bar-popup-left-logo">
                                <?php if ($image_one['url']): ?>
                                    <a href="<?php echo esc_url($settings['image_url']); ?>">
                                        <?php
                                        if ($image_one['url']) {
                                            if (!empty($image_one['alt'])) {
                                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                                            } else {
                                                echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                            }
                                        }
                                        ?>
                                    </a>
                                <?php endif; ?>
                                <div class="responsive-menu"></div>
                            </div>

                            <?php if ('yes' === $settings['enable_social'] && !empty($settings['social_media'])): ?>
                                <div class="menu__bar-popup-left-social">
                                    <h6>
                                        <?php echo esc_html($settings['content_one']); ?>
                                    </h6>
                                    <ul>
                                        <?php foreach ($settings['social_media'] as $item): ?>
                                            <li><a href="<?php echo esc_url($item['link']['url']); ?>"><i
                                                        class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Header Area End -->

        <?php endif; ?>

        <?php if ('design-3' === $settings['select_design']): ?>

            <!-- Header Area Start -->
     

                <div class="custom__container">
                    <div class="top__header-bg p-relative">
                        <div class="row align-items-center">
                            <div class="col-xl-3 col-lg-3 col-6">
                                <div class="header__area-menubar-left">
                                    <div class="header__area-menubar-left-logo three">
                                        <?php if ($logo['url']): ?>
                                            <a href="<?php echo esc_url($settings['logo_url']); ?>">
                                                <?php
                                                if ($logo['url']) {
                                                    if (!empty($logo['alt'])) {
                                                        echo '<img src="' . esc_url($logo['url']) . '" alt="' . esc_attr($logo['alt']) . '" />';
                                                    } else {
                                                        echo '<img src="' . esc_url($logo['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                                    }
                                                }
                                                ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-5 col-lg-7 col-1">
                                <div class="header__area-menubar-center-menu three menu-responsive">

                                    <?php
                                    wp_nav_menu(
                                        array(
                                            'menu' => $settings['nav_menu'],
                                            'menu_id' => 'mobilemenu',
                                            'menu_class' => 'd-block',
                                        )
                                    );
                                    ?>



                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-2 col-5">
                                <div class="header__area-menubar-right three">
                                    <div class="header__area-menubar-right-search three">
                                        <div class="search">
                                            <span class="header__area-menubar-right-search-icon open"><i
                                                    class="fal fa-search"></i></span>
                                        </div>
                                        <div class="header__area-menubar-right-search-box">
                                            <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
                                                <input type="search" placeholder="<?php echo esc_attr($settings['placeholder']); ?>"
                                                    value="<?php the_search_query(); ?>" name="s">
                                                <button value="Search" type="submit"><i class="fal fa-search"></i>
                                                </button>
                                            </form> <span class="header__area-menubar-right-search-box-icon"><i
                                                    class="fal fa-times"></i></span>
                                        </div>
                                    </div>
                                    <div class="header__area-menubar-right-sidebar">
                                        <div class="header__area-menubar-right-sidebar-popup-icon"><i
                                                class="flaticon-dots-menu"></i></div>
                                    </div>
                                    <div class="header__area-menubar-right-contact three">
                                        <div class="header__area-menubar-right-contact-icon">
                                            <i class="<?php echo esc_attr($settings['cta_icon']['value']); ?>"></i>
                                        </div>
                                        <div class="header__area-menubar-right-contact-info">
                                            <span>
                                                <?php echo esc_html($settings['cta_subtitle']); ?>
                                            </span>
                                            <h6><a href="<?php echo esc_url($settings['cta_item_url']); ?>"><?php echo esc_html($settings['cta_title']); ?></a></h6>
                                        </div>
                                    </div>
                                    <div class="header__area-menubar-right-responsive-menu menu__bar">
                                        <i class="flaticon-dots-menu"></i>
                                    </div>
                                    <!-- sidebar Menu Start -->
                                    <div class="header__area-menubar-right-sidebar-popup three">
                                        <div class="sidebar-close-btn"><i class="fal fa-times"></i></div>
                                        <?php
                                        if (!empty($settings['select_emplate'])) {
                                            // The plugin's function to get the content of the selected custom template
                                            echo Plugin::$instance->frontend->get_builder_content($settings['select_emplate'], true);
                                        } else {
                                            // If no custom template is selected
                                            echo 'Please select a template.';
                                        }
                                        ?>

                                    </div>
                                    <div class="sidebar-overlay"></div>
                                    <!-- sidebar Menu Start -->
                                </div>
                                <div class="menu__bar-popup three">
                                    <div class="menu__bar-popup-close"><i class="fal fa-times"></i></div>
                                    <div class="menu__bar-popup-left">
                                        <div class="menu__bar-popup-left-logo">
                                            <?php if ($image_one['url']): ?>
                                                <a href="<?php echo esc_url($settings['image_url']); ?>">
                                                    <?php
                                                    if ($image_one['url']) {
                                                        if (!empty($image_one['alt'])) {
                                                            echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr($image_one['alt']) . '" />';
                                                        } else {
                                                            echo '<img src="' . esc_url($image_one['url']) . '" alt="' . esc_attr(__('No alt text', 'noxiy-toolkit')) . '" />';
                                                        }
                                                    }
                                                    ?>
                                                </a>
                                            <?php endif; ?>
                                            <div class="responsive-menu"></div>
                                        </div>
                                        <?php if ('yes' === $settings['enable_social'] && !empty($settings['social_media'])): ?>
                                            <div class="menu__bar-popup-left-social">
                                                <h6>
                                                    <?php echo esc_html($settings['content_one']); ?>
                                                </h6>
                                                <ul>
                                                    <?php foreach ($settings['social_media'] as $item): ?>
                                                        <li><a href="<?php echo esc_url($item['link']['url']); ?>"><i
                                                                    class="<?php echo esc_attr($item['icon']['value']); ?>"></i></a></li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
          
            <!-- Header Area End -->
        <?php endif; ?>


        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Main_Header_Noxiy);