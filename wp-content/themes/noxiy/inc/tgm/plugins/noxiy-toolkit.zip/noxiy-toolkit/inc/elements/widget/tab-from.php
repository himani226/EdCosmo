<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Tab_From_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'tab_form_noxiy';
    }

    public function get_title()
    {
        return esc_html__('Tab From - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-toolkit'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'from', 'tab'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'noxiy-toolkit'),
            ]
        );


        $content = new Repeater();

        $content->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'noxiy-toolkit'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fa fa-star',
                    'library' => 'brands',
                ],
            ]
        );

        $content->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );



        $content->add_control(
            'shortcode',
            [
                'label' => esc_html__('Shortcode', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
            ]
        );



        $this->add_control(
            'content_items',
            [
                'label' => esc_html__('Content Items', 'noxiy-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $content->get_controls(),
                'default' => [
                    [
                        'title' => esc_html__('Wellness Program', 'noxiy-toolkit'),
                    ],

                    [
                        'title' => esc_html__('Specialty Care', 'noxiy-toolkit'),
                    ],
                ],

                'title_field' => '{{{ title }}}',
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>

        <!-- Quote Area Start -->
        <div class="quote__area">

            <div class="container">

                <div class="row">
                    <div class="col-xl-4 col-lg-5 lg-mb-30">
                        <div class="quote__area-left">
                            <ul class="nav">
                                <?php
                                $counter = 1;
                                foreach ($settings['content_items'] as $keys => $item): ?>
                                    <li>
                                        <h6 class="noxiy-tab-menu <?php echo $keys === 1 ? 'active' : ''; ?>" data-bs-toggle="pill"
                                            data-bs-target="#tab<?php echo $counter; ?>"><i
                                                class="<?php echo esc_attr($item['icon']['value']); ?>"></i>
                                            <?php echo esc_html($item['title']); ?>
                                        </h6>
                                    </li>
                                    <?php
                                    $counter++;
                                endforeach; ?>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-8 col-lg-7">
                        <div class="tab-content">
                            <?php
                            $counter = 1;
                            foreach ($settings['content_items'] as $keys => $item): ?>
                                <div class="tab-pane fade <?php echo $keys === 1 ? 'show active' : ''; ?>"
                                    id="tab<?php echo $counter; ?>">
                                    <div class="quote__area-right-form">
                                        <?php echo do_shortcode($item['shortcode']); ?>
                                    </div>
                                </div>
                                <?php
                                $counter++;
                            endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Quote Area End -->




        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Tab_From_Noxiy);