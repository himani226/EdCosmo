<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Offcanvas_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'offcanvas-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Offcanvas - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-builder'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Search', 'Icon', 'header'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'select_emplate',
            [
                'label' => __('Select a Template', 'noxiy-toolkit'),
                'type' => Controls_Manager::SELECT2,
                'options' => noxiy_template_builder(),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style Normal', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup-icon i::before' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'menu_align',
            [
                'label' => esc_html__('Alignment', 'noxiy-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'right',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup-icon' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup-icon i::before' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'more_options',
			[
				'label' => esc_html__( 'Offcanvas', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
            'popup_bg',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup' => 'background: {{VALUE}}',
                ],
            ]
        );


        $this->add_control(
            'popup_icon_color',
            [
                'label' => esc_html__('Close Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup .sidebar-close-btn i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'popup_icon_bg',
            [
                'label' => esc_html__('Close Icon BG', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-sidebar-popup .sidebar-close-btn i' => 'background: {{VALUE}}',
                ],
            ]
        );


        $this->end_controls_section();

       
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>

        <div class="offcanvas-noxiy">
            <div class="header__area-menubar-right-sidebar-popup-icon"><i class="flaticon-dots-menu"></i></div>
            <!-- sidebar Menu Start -->
            <div class="header__area-menubar-right-sidebar-popup">
                <div class="sidebar-close-btn"><i class="fal fa-times"></i></div>
                <?php
                if (!empty($settings['select_emplate'])) {
                    // The plugin's function to get the content of the selected custom template
                    echo Plugin::$instance->frontend->get_builder_content($settings['select_emplate'], true);
                } else {
                    // If no custom template is selected
                    echo 'Please select a template.';
                }
                ?>
            </div>
            <div class="sidebar-overlay"></div>
        </div>

        <?php
    }
}

Plugin::instance()->widgets_manager->register(new Offcanvas_Noxiy);