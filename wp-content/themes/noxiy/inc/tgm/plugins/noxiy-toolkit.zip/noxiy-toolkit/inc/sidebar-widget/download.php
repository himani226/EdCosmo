<?php
if (!defined('ABSPATH')) exit; // Exit if accessed directly

CSF::createWidget('csf_download_widget', array(
    'title'       => esc_html__('Download Info - noxiy', 'noxiy-toolkit'),
    'classname'   => 'csf-download-widget',
    'description' =>  esc_html__('This Widget for Download Info - noxiy', 'noxiy-toolkit'),
    'fields'      => array(

        array(
            'id'      => 'title',
            'type'    => 'text',
            'title'   => esc_html__('Title', 'noxiy-toolkit'),
            'default' => esc_html__('Download', 'noxiy-toolkit'),
        ),

        array(
            'id'           => 'one_logo',
            'type'         => 'media',
            'title'        => esc_html__('Icon', 'noxiy-toolkit'),
            'library'      => 'image',
            'url'          => false,
            'button_title' => esc_html__('Upload', 'noxiy-toolkit'),
            'default'   => array(
                'url' => get_theme_file_uri('assets/img/icon/pdf.png'),
                'thumbnail' => get_theme_file_uri('assets/img/icon/pdf.png'),
            ),
        ),

        array(
            'id'      => 'btn_text_one',
            'type'    => 'text',
            'title'   => esc_html__('PDF Button', 'noxiy-toolkit'),
            'default' => esc_html__('Our Brochures', 'noxiy-toolkit'),
        ),

        array(
            'id'      => 'btn_url_one',
            'type'    => 'text',
            'title'   => esc_html__('PDF URL', 'noxiy-toolkit'),
            'default' => esc_attr__('http://google.com', 'noxiy-toolkit'),
        ),

        array(
            'id'           => 'two_logo',
            'type'         => 'media',
            'title'        => esc_html__('Icon', 'noxiy-toolkit'),
            'library'      => 'image',
            'url'          => false,
            'button_title' => esc_html__('Upload', 'noxiy-toolkit'),
            'default'   => array(
                'url' => get_theme_file_uri('assets/img/icon/document.png'),
                'thumbnail' => get_theme_file_uri('assets/img/icon/document.png'),
            ),
        ),

        array(
            'id'      => 'btn_text_two',
            'type'    => 'text',
            'title'   => esc_html__('Company Button', 'noxiy-toolkit'),
            'default' => esc_html__('Company Details', 'noxiy-toolkit'),
        ),

        array(
            'id'      => 'btn_url_two',
            'type'    => 'text',
            'title'   => esc_html__('Company File URL', 'noxiy-toolkit'),
            'default' => esc_attr__('http://google.com', 'noxiy-toolkit'),
        ),
    )
));


if (!function_exists('csf_download_widget')) {
    function csf_download_widget($args, $instance)
    {

        echo $args['before_widget'];

        $widget_title = $instance['title'];
        $one_logo     = $instance['one_logo'];
        $two_logo     = $instance['two_logo'];
?>

        <h2><?php echo esc_html($widget_title); ?></h2>
        <div class="all__sidebar-item-download">
            <ul>
                <li><a href="<?php echo esc_url($instance['btn_url_one']); ?>">
                        <?php if (!empty($one_logo['url'])) : ?>
                            <img src="<?php echo esc_url($one_logo['url']); ?>" alt="pdf">
                        <?php endif; ?>
                        <?php echo esc_html($instance['btn_text_one']); ?> <i class="fal fa-arrow-to-bottom"></i></a></li>
                <li><a href="<?php echo esc_url($instance['btn_url_two']); ?>">
                        <?php if (!empty($two_logo['url'])) : ?>
                            <img src="<?php echo esc_url($two_logo['url']); ?>" alt="document">
                        <?php endif; ?>
                        <?php echo esc_html($instance['btn_text_two']); ?> <i class="fal fa-arrow-to-bottom"></i></a></li>
            </ul>
        </div>

<?php
        echo $args['after_widget'];
    }
}
