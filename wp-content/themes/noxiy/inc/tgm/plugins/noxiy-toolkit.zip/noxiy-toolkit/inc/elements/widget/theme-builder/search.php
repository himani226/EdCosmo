<?php

namespace Elementor;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH'))
    exit;

class Search_Noxiy extends Widget_Base
{
    public function get_name()
    {
        return 'search-noxiy';
    }

    public function get_title()
    {
        return esc_html__('Search - Noxiy', 'noxiy-toolkit');
    }

    public function get_icon()
    {
        return 'eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['noxiy-builder'];
    }

    public function get_keywords()
    {
        return ['Noxiy', 'Toolkit', 'Search', 'Icon', 'header'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Section Content', 'noxiy-toolkit'),
            ]
        );

        $this->add_control(
            'placeholder',
            [
                'label' => esc_html__('Placeholder', 'noxiy-toolkit'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Search...', 'noxiy-toolkit'),
                'label_block' => true,
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style Normal', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'noxiy-toolkit'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-icon.open i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'menu_align',
            [
                'label' => esc_html__('Alignment', 'noxiy-toolkit'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'noxiy-toolkit'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'right',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'search_icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-icon.open i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'search_icon_hover',
            [
                'label' => esc_html__('Hover Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-icon.open i:hover' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->end_controls_section();

        $this->start_controls_section(
            'style_popup',
            [
                'label' => esc_html__('Style Popup', 'noxiy-toolkit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'search_bg',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-box' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'close_icon',
            [
                'label' => esc_html__('Close Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-box.active span i' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
			'more_options',
			[
				'label' => esc_html__( 'Search Form', 'noxiy-toolkit' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
            'input_bg',
            [
                'label' => esc_html__('Background', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-box input' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'input_color',
            [
                'label' => esc_html__('Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-box input' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'input_icon_color',
            [
                'label' => esc_html__('Icon Color', 'noxiy-toolkit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .header__area-menubar-right-search-box button' => 'color: {{VALUE}}',
                ],
            ]
        );


        $this->end_controls_section();
    }


    protected function render()
    {
        $settings = $this->get_settings_for_display();

        ?>

            <div class="header__area-menubar-right-search">
                <div class="search">
                    <span class="header__area-menubar-right-search-icon open"><i class="fal fa-search"></i></span>
                </div>
                <div class="header__area-menubar-right-search-box">
                <form method="get" action="<?php echo esc_url(home_url('/')); ?>">
                    <input type="search" placeholder="<?php echo esc_attr($settings['placeholder']); ?>"
                        value="<?php the_search_query(); ?>" name="s">
                    <button value="Search" type="submit"><i class="fal fa-search"></i>
                    </button>
                </form>
                    <span class="header__area-menubar-right-search-box-icon"><i class="fal fa-times"></i></span>
                </div>
            </div>

    <?php
    }
}

Plugin::instance()->widgets_manager->register(new Search_Noxiy);